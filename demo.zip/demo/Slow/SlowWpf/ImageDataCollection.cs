﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlowWpf
{

    public class ImageDataCollection : ObservableCollection<ImageData>
    {
        public ImageDataCollection()
        {
            for (int i = 0; i <= 1000; i++)
            {
                this.Add(new ImageData
                {
                    ImageName = $"turtle.jpg {i}",
                    ImagePath = new Uri("Images/turtle.jpg", UriKind.Relative)
                });
            }
        }
    }
}
