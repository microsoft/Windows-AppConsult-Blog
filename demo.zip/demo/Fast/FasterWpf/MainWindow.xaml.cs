﻿//MICROSOFT, DISCLAIMER:
//THIS SAMPLE CODE IS PROVIDED FOR THE PURPOSE OF ILLUSTRATION ONLY AND IS NOT INTENDED TO BE USED IN A PRODUCTION ENVIRONMENT.
//THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FasterWpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Stopwatch sw;
        //MarkOperationResult result;
        //Guid guid;
        public MainWindow()
        {
            InitializeComponent();
            sw = new Stopwatch();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            sw.Start();
            //result = DataCollection.CommentMarkProfile(1, "Starting Operation");
            //this.DataContext = new ImageDataCollection();

            this.Dispatcher.BeginInvoke(DispatcherPriority.Loaded, new Action(() =>
            {
                sw.Stop();
                TimeTextBox.Text = $"{sw.ElapsedMilliseconds} ms, {sw.Elapsed.Seconds}.{sw.Elapsed.Milliseconds} sec";
                //result = DataCollection.CommentMarkProfile(1, "Ending Operation");
            }));


        }
    }
}
