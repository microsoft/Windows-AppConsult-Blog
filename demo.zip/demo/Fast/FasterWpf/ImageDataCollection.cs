﻿//MICROSOFT, DISCLAIMER:
//THIS SAMPLE CODE IS PROVIDED FOR THE PURPOSE OF ILLUSTRATION ONLY AND IS NOT INTENDED TO BE USED IN A PRODUCTION ENVIRONMENT.
//THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FasterWpf
{

    public class ImageDataCollection : ObservableCollection<ImageData>
    {
        public ImageDataCollection()
        {
            for (int i = 0; i <= 5000; i++)
            {
                this.Add(new ImageData
                {
                    ImageName = $"turtle.jpg {i}",
                    ImagePath = new Uri("Images/turtle.jpg", UriKind.Relative)
                });
            }
        }
    }
}
