﻿//MICROSOFT, DISCLAIMER:
//THIS SAMPLE CODE IS PROVIDED FOR THE PURPOSE OF ILLUSTRATION ONLY AND IS NOT INTENDED TO BE USED IN A PRODUCTION ENVIRONMENT.
//THIS SAMPLE CODE AND ANY RELATED INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FasterWpf
{
    public class ImageData
    {
        public Uri ImagePath { get; set; }
        public string ImageName { get; set; }

        //#region

        //public string MyProperty1 { get; set; }
        //public string MyProperty2 { get; set; }
        //public string MyProperty3 { get; set; }
        //public string MyProperty4 { get; set; }
        //public string MyProperty5 { get; set; }
        //public string MyProperty6 { get; set; }
        //public string MyProperty7 { get; set; }
        //public string MyProperty8 { get; set; }
        //public string MyProperty9 { get; set; }
        //public string MyProperty10 { get; set; }
        //public string MyProperty11 { get; set; }
        //public string MyProperty12 { get; set; }
        //public string MyProperty13 { get; set; }
        //public string MyProperty14 { get; set; }
        //public string MyProperty15 { get; set; }
        //public string MyProperty16 { get; set; }
        //public string MyProperty17 { get; set; }
        //public string MyProperty18 { get; set; }
        //public string MyProperty19 { get; set; }
        //public string MyProperty20 { get; set; }
        //public string MyProperty21 { get; set; }
        //public string MyProperty22 { get; set; }
        //#endregion

    }
}
